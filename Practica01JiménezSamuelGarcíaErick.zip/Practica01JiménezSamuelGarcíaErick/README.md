# Practica 01
### Estructura de Datos 2022-1

---
### Integrantes del Equipo
#### Samuel Jiménez Milke - 318226837
#### Erick Iram García Velasco  - 318044309

---

## Descripción De la Practica
La practica consistiá en hacer mas eficientes 3 algoritmos, para ello primero teníamos que entender el funcionamiento de los algoritmos, luego identificar las partes del codigo que se podrían mejorar y por último desarrollar una solución mas eficiente de estos algoritmos.  

---

## Trabajo en Equipo
Mediante mensajes de texto nos organizamos y  distribuimos el trabajo. Erick realizaría la Actividad 1 y Samuel realizaría la Actividad 2 y 3. Juntos realizaríamos la Actividad 4, Erick se encargaría de llenar la tabla referente al algoritmo de la Act.1 y Samuel haría lo mismo para los algoritmos de la Act. 2 y 3.

También decidimos usar GitHub para entregar la practica.

---

## Instrucciones de compilación y ejecución
Primero que nada, necesitamos contar con Apache Ant y Java instalados en nuestro sistema. Una vez que cumplamos con lo anterior, procedemos descargar las pruebas desde el link proporcionado en classroom o desde el siguiente link: 

https://drive.google.com/drive/folders/1cqcWt2KbeYLQUUILEjI-ZVpKYw672W4m?usp=sharing.

Una vez descargado el archivo, lo extraemos dentro de la carpeta "Tests" que se encuentra en la raiz del proyecto.

A continuación abrimos una terminal y nos dirigimos al directorio del proyecto. Una vez alli, ejecutamos el comando "ant build && ant jar" para generar todos los archivos .class y generar el archivo ejecutable del proyecto. Para ejecutar el proyecto, basta con ejecutar el comando "ant run".